// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Modified By: Gary Clark
// 01/29/22
//

#include <iostream>
#include <exception>
#include <typeinfo>

//custom exception derived from std::exception
struct newException : public std::exception {
    const char* what() const throw () {
        return "My Custom Exception";
    }
};

bool do_even_more_custom_application_logic() throw (std::exception) //throw any std exception
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;
    //custom logic
    char test1[] = "dsfsdjhkjjksdgagjkadkgakadghjkag";
    if (sizeof(test1) >= 5) {
        throw std::length_error("Too Many Characters"); //throw std::length_error
    }
    
    return true;
}
void do_custom_application_logic() throw (newException) //should throw custom exception
{
    std::cout << "Running Custom Application Logic." << std::endl;
    //handler wrappeing do_even_more_custom_application_logic
    try {
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (std::exception& ex) { //catches std::exception
        std::cout << ex.what() << std::endl; //outputs exception.what() to console
        throw newException(); //throws custom exception to main()
    }
   
    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den) throw(std::exception)
{

    if (den == 0) { //checks for 0 in denominator
        throw std::runtime_error("Divide By 0 Error"); //throws runtime_error
    }
    return (num / den); 
}

void do_division()
{
    float numerator = 10.0f;
    float denominator = 0;
    try { //try block handle  divide function
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::exception& e) { //catch exception thrown by divide using std::runtime_error
        std::cerr << "Exception Caught: " << typeid(e).name() << std::endl; //type of exception
        std::cerr << "Description: " << e.what() << std::endl; //description of exception
    }
   
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try { //try these functions
        do_division();
        do_custom_application_logic();
    }
    catch (newException& exc) { //catch custom exception
        std::cout << exc.what() << std::endl;
    }
    catch (const char* msg) { //catch std exception
        std::cerr << msg << std::endl;
    }
    catch (...) { //catch all other uncaught exceptions
        std::cout << "Default Exception" << std::endl;
    }
    return 0;
    
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu